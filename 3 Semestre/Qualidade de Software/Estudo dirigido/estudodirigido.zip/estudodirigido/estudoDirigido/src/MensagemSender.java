public interface MensagemSender {
    void enviarMensagem(String destinatario, String mensagem);
}